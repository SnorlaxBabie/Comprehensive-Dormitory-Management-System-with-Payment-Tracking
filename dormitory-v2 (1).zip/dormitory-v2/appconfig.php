<?php 
 require_once 'config/database.php';
?>